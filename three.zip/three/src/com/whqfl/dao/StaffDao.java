package com.whqfl.dao;

import java.util.Map;

public interface StaffDao {
    /**
     * 根据账户密码登陆
     * @param staffId
     * @param password
     * @return
     */
    Map<String,Object> login(Integer staffId, String password);
}
