package com.whqfl.dao;

public interface ChangePassDao {
    int pass(Integer staffId, String password);


}
