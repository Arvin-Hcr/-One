package com.whqfl.dao;

import java.util.Map;

public interface StaffDao1 {
    Map<String,Object> login(Integer userId, String phone);
}
