package com.whqfl.service;


import java.util.Map;

public interface StaffService {
    /**
     * 根据账户密码登陆
     * @param staffId
     * @param password
     * @return
     */
    Map<String,Object> login(Integer staffId, String password) throws Exception;
}
