package com.whqfl.service;

import java.util.Map;

public interface ChangePassService {
    int pass(Integer staffId, String password)throws Exception;
}
